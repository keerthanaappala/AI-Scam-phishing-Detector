"""Streamlit UI: Scam & Phishing Detector.

Run with:  streamlit run app/streamlit_app.py
"""
import json
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pandas as pd  # noqa: E402
import streamlit as st  # noqa: E402

from src.config import METRICS_FILE, REPORTS_DIR  # noqa: E402
from src.predictor import ScamDetector, models_ready  # noqa: E402

st.set_page_config(page_title="Scam & Phishing Detector", page_icon="🛡️", layout="wide")

EXAMPLE_MESSAGES = {
    "(type your own)": "",
    "Bank phishing": "URGENT: Your HDFC account has been suspended. Verify your KYC now: http://hdfc-kyc-update.top/login",
    "Prize scam": "Congratulations! You have won $5000 in our lucky draw. Claim your prize before midnight!!!",
    "Delivery fee scam": "FedEx: your package could not be delivered. Pay a $1.99 fee to reschedule: http://fedex-redelivery.click/pay",
    "Genuine OTP": "Your OTP is 482913. Do not share it with anyone. - Chase",
    "Friendly message": "Hey, are we still on for lunch tomorrow at noon?",
}
EXAMPLE_URLS = {
    "(type your own)": "",
    "Look-alike login page": "http://paypal.com.account-verify.top/signin",
    "Brand + keywords + risky TLD": "paypal-secure-login.xyz/verify/account",
    "Raw IP address": "http://192.168.4.77/bank/login.php?id=123",
    "Shortened link": "http://bit.ly/3xYz9aB",
    "Legitimate site": "https://www.wikipedia.org",
}
LEVEL_ICON = {"Low": "🟢", "Medium": "🟠", "High": "🔴"}


@st.cache_resource(show_spinner=False)
def get_detector() -> ScamDetector:
    if not models_ready():
        from src.train import train_all
        with st.spinner("First run: downloading public data and training models (about a minute)..."):
            train_all()
    return ScamDetector()


def load_metrics() -> dict:
    path = REPORTS_DIR / METRICS_FILE
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def log_scan(result: dict) -> None:
    st.session_state.setdefault("history", []).append({
        "time": datetime.now().strftime("%H:%M:%S"),
        "type": result["type"],
        "input": result["input"][:80],
        "risk_score": result["risk_score"],
        "risk_level": result["risk_level"],
    })


def show_banner(result: dict) -> None:
    level, score = result["risk_level"], result["risk_score"]
    text = f"{LEVEL_ICON[level]} **{level} risk** (score {score}/100)"
    if level == "High":
        st.error(text + " - do not click links, reply, or share any codes or personal details.")
    elif level == "Medium":
        st.warning(text + " - be careful; verify through the organisation's official website or app.")
    else:
        st.success(text + " - no strong scam signals found, but stay alert.")
    st.progress(min(max(score / 100.0, 0.0), 1.0))


def show_url_result(r: dict) -> None:
    c1, c2, c3 = st.columns(3)
    c1.metric("Risk score", f"{r['risk_score']}/100")
    c2.metric("ML phishing probability", f"{r['ml_probability'] * 100:.1f}%")
    c3.metric("Rule-based score", f"{r['heuristic_score'] * 100:.0f}/100")
    st.markdown("**Why?**")
    if r["flags"]:
        for f in r["flags"]:
            st.write(f"- {f['label']}")
    else:
        st.write("- No suspicious structural patterns found in the URL.")
    if r["model_signals"]:
        st.markdown("**Features the model weighted most for this URL**")
        st.dataframe(pd.DataFrame(r["model_signals"]), hide_index=True)


def show_message_result(r: dict) -> None:
    c1, c2, c3 = st.columns(3)
    c1.metric("Risk score", f"{r['risk_score']}/100")
    c2.metric("ML scam probability", f"{r['ml_probability'] * 100:.1f}%")
    c3.metric("Rule-based score", f"{r['heuristic_score'] * 100:.0f}/100")
    st.markdown("**Why?**")
    if r["flags"]:
        for f in r["flags"]:
            st.write(f"- {f['label']}")
    else:
        st.write("- No typical scam wording patterns found.")

    wc = r["word_contributions"]
    left, right = st.columns(2)
    with left:
        st.markdown("**Words pushing toward SCAM**")
        if wc["scam"]:
            st.dataframe(pd.DataFrame(wc["scam"]), hide_index=True)
        else:
            st.caption("None")
    with right:
        st.markdown("**Words pushing toward SAFE**")
        if wc["safe"]:
            st.dataframe(pd.DataFrame(wc["safe"]), hide_index=True)
        else:
            st.caption("None")

    for u in r["url_results"]:
        with st.expander(f"Link found: {u['input']}  -  {LEVEL_ICON[u['risk_level']]} {u['risk_level']} ({u['risk_score']}/100)"):
            show_url_result(u)


# ----------------------------------------------------------------------------- layout
detector = get_detector()
metrics = load_metrics()

with st.sidebar:
    st.title("🛡️ Scam & Phishing Detector")
    st.caption("All analysis runs locally on your machine. URLs are never visited and nothing is sent to any server.")
    st.divider()
    st.markdown("**Risk levels**")
    st.write("🟢 Low: below 30")
    st.write("🟠 Medium: 30 to 60")
    st.write("🔴 High: 60 and above")
    st.divider()
    for key, label in (("message_model", "Message model data"), ("url_model", "URL model data")):
        if key in metrics:
            st.caption(f"**{label}:** {metrics[key]['dataset']['source']}")

tab_analyze, tab_dash, tab_eval, tab_about = st.tabs(["🔍 Analyze", "📊 Dashboard", "🧪 Model evaluation", "ℹ️ About"])

# ---- Analyze
with tab_analyze:
    mode = st.radio("What do you want to check?", ["Message (SMS / email text)", "URL"], horizontal=True)
    if mode.startswith("Message"):
        example = st.selectbox("Try an example", list(EXAMPLE_MESSAGES.keys()), key="ex_msg")
        text = st.text_area("Paste the message", value=EXAMPLE_MESSAGES[example], height=150, key=f"msg_{example}")
        if st.button("Analyze message", type="primary"):
            if not text.strip():
                st.warning("Please enter a message first.")
            else:
                result = detector.analyze_message(text)
                log_scan(result)
                show_banner(result)
                show_message_result(result)
    else:
        example = st.selectbox("Try an example", list(EXAMPLE_URLS.keys()), key="ex_url")
        url = st.text_input("Enter the URL (it will NOT be opened)", value=EXAMPLE_URLS[example], key=f"url_{example}")
        if st.button("Analyze URL", type="primary"):
            if not url.strip():
                st.warning("Please enter a URL first.")
            else:
                result = detector.analyze_url(url)
                log_scan(result)
                show_banner(result)
                show_url_result(result)

# ---- Dashboard
with tab_dash:
    st.subheader("Session scan history")
    history = st.session_state.get("history", [])
    if not history:
        st.info("No scans yet. Analyze a message or URL in the first tab and the results will appear here.")
    else:
        hist = pd.DataFrame(history)
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Total scans", len(hist))
        c2.metric("High risk", int((hist["risk_level"] == "High").sum()))
        c3.metric("Medium risk", int((hist["risk_level"] == "Medium").sum()))
        c4.metric("Average risk", f"{hist['risk_score'].mean():.1f}")
        left, right = st.columns(2)
        with left:
            st.markdown("**Scans by risk level**")
            counts = hist["risk_level"].value_counts().reindex(["Low", "Medium", "High"]).fillna(0)
            st.bar_chart(counts)
        with right:
            st.markdown("**Risk score over time**")
            st.line_chart(hist["risk_score"])
        st.dataframe(hist.iloc[::-1], hide_index=True)
        st.download_button("Download history (CSV)", hist.to_csv(index=False), "scan_history.csv", "text/csv")
        if st.button("Clear history"):
            st.session_state["history"] = []
            st.rerun()

    st.subheader("Training data overview")
    if metrics:
        rows = []
        for key, name in (("message_model", "Messages"), ("url_model", "URLs")):
            ds = metrics[key]["dataset"]
            rows.append({"Dataset": name, "Samples": ds["n_samples"], "Train": ds["n_train"], "Test": ds["n_test"],
                         "Safe": ds["class_counts"]["safe"], "Scam / phishing": ds["class_counts"]["scam"],
                         "Source": ds["source"]})
        st.dataframe(pd.DataFrame(rows), hide_index=True)
    else:
        st.info("Run `python -m src.train` to generate dataset statistics.")

# ---- Evaluation
with tab_eval:
    if not metrics:
        st.info("No evaluation report found. Run `python -m src.train`.")
    else:
        st.caption("Metrics are computed on a held-out 20% test split. Scores on synthetic data are optimistic.")
        for key, title, prefix in (("message_model", "Message model", "message"), ("url_model", "URL model", "url")):
            m = metrics[key]
            st.subheader(title)
            rows = [{"Model": n, "Accuracy": v["accuracy"], "Precision": v["precision"], "Recall": v["recall"],
                     "F1": v["f1"], "ROC-AUC": v["roc_auc"]} for n, v in m["models"].items()]
            st.dataframe(pd.DataFrame(rows).round(4), hide_index=True)
            cv = m["cross_validation_f1"]
            st.caption(f"Selected model: **{m['selected_model']}** | 5-fold cross-validated F1: "
                       f"{cv['mean']:.3f} +/- {cv['std']:.3f}")
            imgs = [REPORTS_DIR / f"{prefix}_confusion_matrix.png", REPORTS_DIR / f"{prefix}_roc.png",
                    REPORTS_DIR / ("message_top_words.png" if prefix == "message" else "url_feature_importance.png")]
            cols = st.columns(3)
            for col, img in zip(cols, imgs):
                if img.exists():
                    col.image(str(img))

# ---- About
with tab_about:
    st.markdown(
        """
### How it works
1. **Message model**: TF-IDF word and phrase features feed a Logistic Regression classifier. Each word's
   contribution is shown, so the explanation is exact rather than guessed.
2. **URL model**: about 30 lexical features (length, IP host, brand impersonation, risky TLDs, keywords...)
   feed a Random Forest. URLs are analysed as text only and never opened.
3. **Rule engine**: plain-language checks (urgency, threats, OTP requests, prizes...) that explain results and
   cover patterns the training data may miss.
4. **Risk score (0-100)**: a weighted blend of the ML probability, the rule score and, for messages, the
   riskiest link inside the message.

### Limitations
- This is an educational tool, not a replacement for security software. It can be wrong in both directions.
- It looks only at text and URL structure. It does not check domain age, reputation or page content.
- Real attackers adapt, so models need retraining on fresh data.
- When the public URL feeds cannot be downloaded the URL model trains on synthetic data and its metrics are
  optimistic. See the README for how to supply a real dataset.
"""
    )