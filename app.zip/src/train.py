"""Train, evaluate and save both models.

    python -m src.train               # download public data (falls back to synthetic offline)
    python -m src.train --offline     # synthetic data only
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, Optional

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import joblib  # noqa: E402
from sklearn.ensemble import RandomForestClassifier  # noqa: E402
from sklearn.feature_extraction.text import TfidfVectorizer  # noqa: E402
from sklearn.linear_model import LogisticRegression  # noqa: E402
from sklearn.metrics import (  # noqa: E402
    accuracy_score, confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score, roc_curve,
)
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split  # noqa: E402
from sklearn.naive_bayes import MultinomialNB  # noqa: E402
from sklearn.pipeline import Pipeline  # noqa: E402
from sklearn.preprocessing import StandardScaler  # noqa: E402

from src.config import (  # noqa: E402
    METRICS_FILE, MESSAGE_MODEL_FILE, MODELS_DIR, RANDOM_STATE, REPORTS_DIR, URL_MODEL_FILE, ensure_dirs,
)
from src.data_loader import load_sms_dataset, load_url_dataset  # noqa: E402
from src.text_preprocessing import clean_text  # noqa: E402
from src.url_features import FEATURE_NAMES, urls_to_frame  # noqa: E402


# ------------------------------------------------------------------ helpers
def compute_metrics(y_true, y_pred, y_score) -> Dict:
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "roc_auc": float(roc_auc_score(y_true, y_score)),
        "confusion_matrix": confusion_matrix(y_true, y_pred).tolist(),
    }


def _plot_confusion(cm, title: str, labels, path: Path) -> None:
    cm = np.array(cm)
    fig, ax = plt.subplots(figsize=(4.2, 3.8))
    ax.imshow(cm, cmap="Blues")
    ax.set_xticks([0, 1]); ax.set_yticks([0, 1])
    ax.set_xticklabels(labels); ax.set_yticklabels(labels)
    ax.set_xlabel("Predicted"); ax.set_ylabel("Actual"); ax.set_title(title)
    for i in range(2):
        for j in range(2):
            ax.text(j, i, int(cm[i, j]), ha="center", va="center",
                    color="white" if cm[i, j] > cm.max() / 2 else "black", fontsize=13)
    fig.tight_layout(); fig.savefig(path, dpi=130); plt.close(fig)


def _plot_roc(curves: Dict, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(4.8, 3.8))
    for name, (fpr, tpr, auc) in curves.items():
        ax.plot(fpr, tpr, label=f"{name} (AUC={auc:.3f})")
    ax.plot([0, 1], [0, 1], "k--", linewidth=0.8)
    ax.set_xlabel("False positive rate"); ax.set_ylabel("True positive rate")
    ax.set_title(title); ax.legend(loc="lower right", fontsize=8)
    fig.tight_layout(); fig.savefig(path, dpi=130); plt.close(fig)


def _plot_barh(labels, values, title: str, path: Path, color: str = "#3b82f6") -> None:
    fig, ax = plt.subplots(figsize=(6, 4.2))
    y = np.arange(len(labels))
    ax.barh(y, values, color=color)
    ax.set_yticks(y); ax.set_yticklabels(labels); ax.invert_yaxis()
    ax.set_title(title)
    fig.tight_layout(); fig.savefig(path, dpi=130); plt.close(fig)


def _class_counts(y) -> Dict[str, int]:
    arr = np.asarray(y)
    return {"safe": int((arr == 0).sum()), "scam": int((arr == 1).sum())}


# ------------------------------------------------------------------ message model
def _tfidf() -> TfidfVectorizer:
    return TfidfVectorizer(preprocessor=clean_text, ngram_range=(1, 2), min_df=2,
                           sublinear_tf=True, max_features=30000)


def train_message_model(models_dir: Path, reports_dir: Path, offline: bool, augment: bool) -> Dict:
    df, source = load_sms_dataset(offline=offline, augment=augment)
    df = df.dropna().drop_duplicates(subset="text").reset_index(drop=True)
    X_train, X_test, y_train, y_test = train_test_split(
        df["text"], df["label"], test_size=0.2, stratify=df["label"], random_state=RANDOM_STATE)

    candidates = {
        "Logistic Regression": Pipeline([("tfidf", _tfidf()),
                                         ("clf", LogisticRegression(max_iter=2000, C=5.0, class_weight="balanced"))]),
        "Naive Bayes (baseline)": Pipeline([("tfidf", _tfidf()), ("clf", MultinomialNB(alpha=0.1))]),
    }
    results, curves = {}, {}
    for name, pipe in candidates.items():
        pipe.fit(X_train, y_train)
        proba = pipe.predict_proba(X_test)[:, 1]
        pred = (proba >= 0.5).astype(int)
        results[name] = compute_metrics(y_test, pred, proba)
        fpr, tpr, _ = roc_curve(y_test, proba)
        curves[name] = (fpr, tpr, results[name]["roc_auc"])

    final_name = "Logistic Regression"   # chosen for exact, word-level explanations
    final = candidates[final_name]
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    cv_scores = cross_val_score(
        Pipeline([("tfidf", _tfidf()), ("clf", LogisticRegression(max_iter=2000, C=5.0, class_weight="balanced"))]),
        X_train, y_train, cv=cv, scoring="f1")

    _plot_confusion(results[final_name]["confusion_matrix"], "Message model: confusion matrix",
                    ["Safe", "Scam"], reports_dir / "message_confusion_matrix.png")
    _plot_roc(curves, "Message model: ROC curves", reports_dir / "message_roc.png")

    coef = final.named_steps["clf"].coef_[0]
    names = final.named_steps["tfidf"].get_feature_names_out()
    order = np.argsort(coef)
    top_scam = order[::-1][:15]
    _plot_barh([names[i] for i in top_scam], [coef[i] for i in top_scam],
               "Top words/phrases pushing toward SCAM", reports_dir / "message_top_words.png", "#dc2626")

    joblib.dump({"pipeline": final, "name": final_name}, models_dir / MESSAGE_MODEL_FILE)
    return {
        "dataset": {"source": source, "n_samples": int(len(df)), "n_train": int(len(X_train)),
                    "n_test": int(len(X_test)), "class_counts": _class_counts(df["label"])},
        "selected_model": final_name, "models": results,
        "cross_validation_f1": {"mean": float(cv_scores.mean()), "std": float(cv_scores.std())},
    }


# ------------------------------------------------------------------ URL model
def train_url_model(models_dir: Path, reports_dir: Path, offline: bool, augment: bool) -> Dict:
    df, source = load_url_dataset(offline=offline, augment=augment)
    df = df.dropna().drop_duplicates(subset="url").reset_index(drop=True)
    X = urls_to_frame(df["url"])
    y = df["label"].astype(int).to_numpy()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=RANDOM_STATE)

    rf = RandomForestClassifier(n_estimators=250, min_samples_leaf=2, class_weight="balanced_subsample",
                                n_jobs=-1, random_state=RANDOM_STATE)
    lr = Pipeline([("scale", StandardScaler()), ("clf", LogisticRegression(max_iter=3000, class_weight="balanced"))])
    candidates = {"Random Forest": rf, "Logistic Regression (baseline)": lr}

    results, curves = {}, {}
    for name, model in candidates.items():
        model.fit(X_train, y_train)
        proba = model.predict_proba(X_test)[:, 1]
        pred = (proba >= 0.5).astype(int)
        results[name] = compute_metrics(y_test, pred, proba)
        fpr, tpr, _ = roc_curve(y_test, proba)
        curves[name] = (fpr, tpr, results[name]["roc_auc"])

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    cv_scores = cross_val_score(
        RandomForestClassifier(n_estimators=100, min_samples_leaf=2, class_weight="balanced_subsample",
                               n_jobs=-1, random_state=RANDOM_STATE),
        X_train, y_train, cv=cv, scoring="f1")

    _plot_confusion(results["Random Forest"]["confusion_matrix"], "URL model: confusion matrix",
                    ["Legit", "Phishing"], reports_dir / "url_confusion_matrix.png")
    _plot_roc(curves, "URL model: ROC curves", reports_dir / "url_roc.png")

    imp = rf.feature_importances_
    top = np.argsort(imp)[::-1][:12]
    _plot_barh([FEATURE_NAMES[i] for i in top], [imp[i] for i in top],
               "URL model: top feature importances", reports_dir / "url_feature_importance.png")

    std = np.array(X_train.std(axis=0), dtype=float)
    std[std == 0] = 1.0
    joblib.dump({
        "model": rf, "feature_names": list(FEATURE_NAMES), "importances": imp,
        "mean": np.array(X_train.mean(axis=0), dtype=float), "std": std,
    }, models_dir / URL_MODEL_FILE)
    return {
        "dataset": {"source": source, "n_samples": int(len(df)), "n_train": int(len(X_train)),
                    "n_test": int(len(X_test)), "class_counts": _class_counts(y)},
        "selected_model": "Random Forest", "models": results,
        "cross_validation_f1": {"mean": float(cv_scores.mean()), "std": float(cv_scores.std())},
    }


# ------------------------------------------------------------------ entry points
def train_all(models_dir: Optional[Path] = None, reports_dir: Optional[Path] = None,
              offline: bool = False, augment: bool = True) -> Dict:
    models_dir = Path(models_dir) if models_dir else MODELS_DIR
    reports_dir = Path(reports_dir) if reports_dir else REPORTS_DIR
    ensure_dirs()
    models_dir.mkdir(parents=True, exist_ok=True)
    reports_dir.mkdir(parents=True, exist_ok=True)

    summary = {
        "message_model": train_message_model(models_dir, reports_dir, offline, augment),
        "url_model": train_url_model(models_dir, reports_dir, offline, augment),
    }
    (reports_dir / METRICS_FILE).write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description="Train the scam & phishing detection models.")
    parser.add_argument("--offline", action="store_true", help="Skip downloads; use synthetic data only.")
    parser.add_argument("--no-augment", action="store_true", help="Do not add synthetic examples to real data.")
    args = parser.parse_args()

    summary = train_all(offline=args.offline, augment=not args.no_augment)
    for key, label in (("message_model", "MESSAGE"), ("url_model", "URL")):
        s = summary[key]
        m = s["models"][s["selected_model"]]
        print(f"\n[{label}] data: {s['dataset']['source']}  (n={s['dataset']['n_samples']})")
        print(f"  model: {s['selected_model']}")
        print(f"  accuracy={m['accuracy']:.3f} precision={m['precision']:.3f} recall={m['recall']:.3f} "
              f"f1={m['f1']:.3f} auc={m['roc_auc']:.3f}")
        cvm = s["cross_validation_f1"]
        print(f"  5-fold CV F1: {cvm['mean']:.3f} +/- {cvm['std']:.3f}")
    print(f"\nSaved models to {MODELS_DIR} and reports to {REPORTS_DIR}")


if __name__ == "__main__":
    main()