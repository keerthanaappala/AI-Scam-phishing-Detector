"""Text cleaning used by the message model.

URLs, long numbers and currency symbols are replaced by placeholder tokens so the
model learns *patterns* ("a link", "a phone number", "money") rather than memorising
specific values.
"""
import re

_URL_RE = re.compile(r"(?i)\b(?:https?://|www\.)\S+")
_BARE_DOMAIN_RE = re.compile(
    r"(?i)\b(?:[a-z0-9-]+\.)+(?:com|net|org|io|co|in|info|biz|xyz|top|club|click|link|online|site|ly|me|us|uk)\b(?:/\S*)?"
)
_LONG_NUM_RE = re.compile(r"\d[\d\-\s]{4,}\d")
_CURRENCY_RE = re.compile(r"[$£€₹]")
_NON_WORD_RE = re.compile(r"[^a-z0-9_ ]+")
_SPACES_RE = re.compile(r"\s+")


def clean_text(text: str) -> str:
    """Normalise a raw message into a compact lowercase string."""
    if not isinstance(text, str):
        text = "" if text is None else str(text)
    text = text.lower()
    text = _URL_RE.sub(" urltoken ", text)
    text = _BARE_DOMAIN_RE.sub(" urltoken ", text)
    text = _CURRENCY_RE.sub(" currencysym ", text)
    text = _LONG_NUM_RE.sub(" longnumtoken ", text)
    text = _NON_WORD_RE.sub(" ", text)
    return _SPACES_RE.sub(" ", text).strip()