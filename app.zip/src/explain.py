"""Human-readable, rule-based explanations.

These rules complement the ML models: they (a) explain *why* something looks risky in
plain language and (b) act as a safety net for patterns the training data may not cover.
Each flag carries a weight; the weights sum (capped at 1.0) into a heuristic score.
"""
from __future__ import annotations

import re
from typing import Dict, List

FEATURE_LABELS = {
    "url_length": "URL length", "host_length": "domain length", "path_length": "path length",
    "query_length": "query-string length", "num_dots": "number of dots",
    "num_hyphens_host": "hyphens in domain", "num_digits": "number of digits",
    "digit_ratio": "share of digits", "host_digit_count": "digits in domain",
    "num_at": "'@' symbols", "num_question": "'?' characters", "num_equals": "'=' characters",
    "num_ampersand": "'&' characters", "num_percent": "'%' characters", "path_depth": "path depth",
    "subdomain_count": "number of subdomains", "tld_length": "TLD length",
    "host_entropy": "domain randomness", "has_ip": "IP address as host", "uses_https": "HTTPS usage",
    "has_port": "non-standard port", "has_punycode": "punycode domain",
    "double_slash_in_path": "'//' in path", "suspicious_tld": "risky TLD",
    "is_shortener": "URL shortener", "keyword_count": "suspicious keywords",
    "keyword_in_host": "suspicious keyword in domain", "brand_mismatch": "brand impersonation (domain)",
    "brand_in_path_mismatch": "brand name in path of unrelated site",
}


def url_flags(f: Dict[str, float]) -> List[Dict]:
    flags: List[Dict] = []

    def add(cond: bool, label: str, weight: float) -> None:
        if cond:
            flags.append({"label": label, "weight": weight})

    add(f["has_ip"] == 1, "Uses a raw IP address instead of a domain name", 0.5)
    add(f["num_at"] > 0, "Contains '@', which can hide the real destination", 0.4)
    add(f["has_punycode"] == 1, "Uses punycode (xn--), often used for look-alike domains", 0.4)
    add(f["brand_mismatch"] == 1, "Mentions a well-known brand but is not on that brand's real domain", 0.5)
    add(f["brand_in_path_mismatch"] == 1, "Brand name appears in the path of an unrelated website", 0.3)
    add(f["suspicious_tld"] == 1, "Uses a top-level domain commonly abused for scams", 0.25)
    add(f["is_shortener"] == 1, "Shortened link hides the final destination", 0.25)
    add(f["keyword_count"] >= 2, "Several sensitive keywords (login, verify, secure, account...)", 0.3)
    add(f["keyword_count"] < 2 and f["keyword_in_host"] == 1, "Sensitive keyword inside the domain name", 0.2)
    add(f["uses_https"] == 0, "Does not use HTTPS", 0.15)
    add(f["url_length"] > 75, "Unusually long URL", 0.15)
    add(f["subdomain_count"] >= 3, "Many subdomains", 0.25)
    add(f["num_hyphens_host"] >= 2, "Several hyphens in the domain name", 0.2)
    add(f["has_port"] == 1, "Uses a non-standard port", 0.15)
    add(f["host_digit_count"] >= 4 and f["has_ip"] == 0, "Many digits in the domain name", 0.15)
    return flags


_RULES = [
    ("Creates urgency or pressure", 0.20,
     r"\b(urgent|immediately|right now|asap|act now|within \d+ ?(hours?|minutes?|hrs?|mins?)|expires? (today|soon)|"
     r"final notice|last chance|before midnight|today only|limited time|offer ends)\b"),
    ("Threatens account suspension, fines or legal action", 0.25,
     r"\b(suspend(ed)?|blocked|locked|closed|deactivat\w+|legal action|arrest|penalt(y|ies)|fines?|terminated|"
     r"unauthori[sz]ed|unusual activity|suspicious (login|activity)|on hold)\b"),
    ("Asks you to share or send a code, PIN or password", 0.35,
     r"(share|send|tell|give|provide|enter|reply with)\s+(\w+\s+){0,3}(otp|code|pin|password|cvv)\b"),
    ("Asks you to verify or confirm personal / account details", 0.30,
     r"\b(verify (your )?(identity|account|details)|confirm your (account|identity|details|login)|"
     r"login details|kyc|card number|billing information|bank details|ssn|social security)\b"),
    ("Promises a prize, reward, refund or free gift", 0.25,
     r"\b(you (have )?won|winner|lottery|lucky draw|jackpot|reward|free gift|gift card|refund|claim (your|now)|"
     r"selected for)\b"),
    ("Mentions money amounts", 0.10, r"[$£€₹]\s?\d|\b(rs\.?|inr|usd)\s?\d"),
    ("Pushes investment, crypto or easy-income offers", 0.25,
     r"\b(crypto|bitcoin|guaranteed returns?|earn .{0,15}(daily|per (day|week))|work from home|double your|"
     r"simple online tasks|pre-approved)\b"),
    ("Asks you to call an unknown phone number", 0.20, r"\bcall\b.{0,40}\+?\d[\d\-\s]{7,}\d|\bcall\b.{0,20}immediately"),
    ("Impersonates a trusted organisation (bank, courier, government)", 0.10,
     r"\b(bank|paypal|amazon|netflix|apple|microsoft|fedex|dhl|usps|ups|irs|hmrc|government|customs|hdfc|sbi|icici|chase)\b"),
]
_COMPILED = [(label, w, re.compile(p, re.IGNORECASE)) for label, w, p in _RULES]
_SAFE_OTP_RE = re.compile(r"(do not|don'?t|never)\s+share", re.IGNORECASE)


def message_flags(text: str) -> List[Dict]:
    flags: List[Dict] = []
    text = text or ""
    safe_otp = bool(_SAFE_OTP_RE.search(text))
    for label, weight, rx in _COMPILED:
        if rx.search(text):
            flags.append({"label": label, "weight": weight})

    letters = [c for c in text if c.isalpha()]
    if len(letters) >= 20 and sum(c.isupper() for c in letters) / len(letters) > 0.5:
        flags.append({"label": "Mostly capital letters (shouting)", "weight": 0.10})
    if text.count("!") >= 3:
        flags.append({"label": "Excessive exclamation marks", "weight": 0.10})
    if safe_otp:
        flags.append({"label": "Warns you NOT to share the code (typical of genuine OTP messages)", "weight": -0.15})
    return flags


def heuristic_score(flags: List[Dict]) -> float:
    return float(min(1.0, max(0.0, sum(f["weight"] for f in flags))))