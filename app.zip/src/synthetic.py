"""Synthetic data generators.

Used for two purposes:
1. Offline fallback so the project always runs, even with no internet.
2. Augmentation: the public SMS Spam Collection is from ~2011 and lacks modern
   phishing styles (bank KYC, delivery fees, OTP theft, crypto). A few hundred
   template-based examples cover those.

IMPORTANT: synthetic data is template-based, so scores on it are optimistic.
"""
from __future__ import annotations

import random
import string
from typing import List

import pandas as pd

LEGIT_DOMAINS = [
    "google.com", "wikipedia.org", "github.com", "stackoverflow.com", "amazon.com",
    "microsoft.com", "apple.com", "nytimes.com", "bbc.co.uk", "cnn.com", "linkedin.com",
    "reddit.com", "python.org", "mozilla.org", "nasa.gov", "harvard.edu", "mit.edu",
    "spotify.com", "netflix.com", "paypal.com", "chase.com", "bankofamerica.com",
    "wellsfargo.com", "dropbox.com", "adobe.com", "medium.com", "imdb.com", "ebay.com",
    "walmart.com", "target.com", "bestbuy.com", "coursera.org", "khanacademy.org",
    "who.int", "irs.gov", "usps.com", "fedex.com", "dhl.com", "stripe.com", "zoom.us",
    "slack.com", "instagram.com", "facebook.com", "youtube.com", "hdfcbank.com",
    "sbi.co.in", "flipkart.com", "irctc.co.in", "ox.ac.uk", "cam.ac.uk",
]
WORDS = [
    "news", "report", "guide", "tutorial", "history", "science", "review", "update",
    "travel", "health", "music", "garden", "recipe", "market", "design", "career",
    "weather", "sports", "culture", "energy", "climate", "software", "research",
]
BRANDS = ["paypal", "apple", "microsoft", "google", "amazon", "netflix", "facebook",
          "dhl", "fedex", "usps", "chase", "hdfc", "icici", "sbi", "binance", "coinbase"]
PHISH_WORDS = ["secure", "login", "verify", "account", "update", "support", "billing",
               "confirm", "signin", "wallet", "recover", "unlock", "service", "alert"]
BAD_TLDS = ["xyz", "top", "club", "click", "link", "online", "site", "icu", "buzz", "tk", "ml", "work", "cyou"]
GOOD_TLDS = ["com", "net", "org", "info", "co"]


def _rand_str(rng: random.Random, n: int, digits: bool = True) -> str:
    alphabet = string.ascii_lowercase + (string.digits if digits else "")
    return "".join(rng.choices(alphabet, k=n))


def make_legit_url(rng: random.Random) -> str:
    domain = rng.choice(LEGIT_DOMAINS)
    scheme = "https" if rng.random() < 0.95 else "http"
    host = ("www." + domain) if rng.random() < 0.5 else domain
    w1, w2 = rng.choice(WORDS), rng.choice(WORDS)
    paths = [
        "", "/", "/about", f"/products/{rng.randint(100, 99999)}", "/login", "/account/settings",
        f"/search?q={w1}", f"/news/{rng.randint(2019, 2026)}/{w1}-{w2}", f"/docs/{w1}",
        f"/help/{w1}", f"/blog/{w1}-{w2}", f"/wiki/{w1.capitalize()}", f"/{w1}/{w2}?page={rng.randint(1, 9)}",
    ]
    return f"{scheme}://{host}{rng.choice(paths)}"


def make_phish_url(rng: random.Random) -> str:
    brand = rng.choice(BRANDS)
    kw = rng.choice(PHISH_WORDS)
    kw2 = rng.choice(PHISH_WORDS)
    tld = rng.choice(BAD_TLDS)
    scheme = "http" if rng.random() < 0.6 else "https"
    pattern = rng.randint(0, 7)
    if pattern == 0:
        return f"{scheme}://{brand}-{kw}-{kw2}.{tld}/{kw}/account"
    if pattern == 1:
        ip = ".".join(str(rng.randint(1, 254)) for _ in range(4))
        return f"http://{ip}/{brand}/{kw}.php?id={rng.randint(1000, 99999)}"
    if pattern == 2:
        return f"{scheme}://{brand}.com.{kw}-{_rand_str(rng, 5, False)}.{tld}/{kw2}"
    if pattern == 3:
        return f"{scheme}://{brand}.com@{_rand_str(rng, 8)}.{rng.choice(BAD_TLDS)}/{kw}"
    if pattern == 4:
        return (f"{scheme}://{kw}-{_rand_str(rng, 4)}{rng.randint(10, 9999)}.{tld}/{brand}/{kw2}"
                f"?session={_rand_str(rng, 16)}&user={rng.randint(1000, 99999)}")
    if pattern == 5:
        return f"http://{rng.choice(['bit.ly', 'tinyurl.com', 'cutt.ly'])}/{_rand_str(rng, 7, True)}"
    if pattern == 6:
        return f"http://xn--{brand[:-1]}-{_rand_str(rng, 3, False)}.{rng.choice(GOOD_TLDS)}/{kw}"
    return f"{scheme}://secure.{brand}.{kw}-{kw2}.{rng.choice(GOOD_TLDS + BAD_TLDS)}/{_rand_str(rng, 10)}/{kw}.html"


def generate_synthetic_urls(n_per_class: int = 1500, seed: int = 42) -> pd.DataFrame:
    rng = random.Random(seed)
    rows = [(make_legit_url(rng), 0) for _ in range(n_per_class)]
    rows += [(make_phish_url(rng), 1) for _ in range(n_per_class)]
    rng.shuffle(rows)
    return pd.DataFrame(rows, columns=["url", "label"])


_SCAM_TEMPLATES = [
    "URGENT: Your {bank} account has been suspended due to unusual activity. Verify your identity now: {url}",
    "Congratulations! You have won {amount} in our lucky draw. Claim your prize before midnight: {url}",
    "{courier}: Your package could not be delivered. Pay a small fee of {small} to reschedule: {url}",
    "Your {brand} password expires today. Confirm your login details immediately to avoid account closure {url}",
    "ALERT! Suspicious login detected on your {bank} card. Share the OTP {code} with our agent to cancel the transaction.",
    "You are pre-approved for a loan of {amount}. No documents needed. Reply YES or click {url}",
    "Final notice: unpaid toll of {small}. Pay now to avoid legal action and extra fines: {url}",
    "Earn {amount} daily from home! Invest in crypto today with guaranteed returns. Join now {url}",
    "Dear customer your KYC is incomplete. Your {bank} account will be blocked in 24 hours. Update at {url}",
    "This is the {bank} fraud department. Call {phone} immediately to secure your funds.",
    "We could not process your {brand} payment. Update your billing information here {url} or your subscription will be cancelled.",
    "Free gift card worth {amount}! Limited offer, tap {url} to claim your {brand} reward now",
    "Your account was accessed from a new device. If this wasn't you, verify now: {url}",
    "Government refund of {amount} is waiting for you. Submit your bank details at {url} to receive it.",
    "WINNER!! You have been selected for a free holiday. Call {phone} now to claim. Offer ends today",
    "Hello, I am a recruiter. Earn {amount} per week with simple online tasks, message me on WhatsApp {phone}",
    "{bank} alert: your card has been locked. Enter your PIN and CVV at {url} to unlock it within 2 hours.",
    "Your {brand} account is on hold. Unusual sign-in detected. Restore access: {url}",
]

_HAM_TEMPLATES = [
    "Hey {name}, are we still meeting at {time}?",
    "Can you send me the report by {time}? Thanks",
    "Don't forget to pick up milk and eggs on your way home",
    "Happy birthday {name}! Hope you have an amazing day",
    "Your {bank} statement for this month is available. Log in at {legit_url} to view it.",
    "Your OTP is {code}. Do not share it with anyone. - {bank}",
    "Your {courier} package will arrive {time}. Track it at {legit_url}",
    "Meeting moved to {time}, see the agenda here {legit_url}",
    "Thanks for dinner last night, it was great!",
    "I'll call you back in 10 minutes",
    "Reminder: dentist appointment {time}",
    "Lunch? I'm near the {place}",
    "Please call me when you get a chance, nothing urgent",
    "The movie starts at {time}, I'll save you a seat",
    "Got the tickets! Sending them over now",
    "Can you review my pull request when you have a minute? {legit_url}",
    "Class is cancelled today, see you next week",
    "Running late, traffic is terrible. Be there in 15",
    "Your order has shipped and will arrive by {time}. Track here: {legit_url}",
    "Did you see the game last night? Unreal finish",
    "Thanks for your payment of {small}. Your receipt is attached to the email we sent.",
]


def _slots(rng: random.Random) -> dict:
    return {
        "bank": rng.choice(["HDFC", "SBI", "ICICI", "Chase", "Wells Fargo", "Barclays", "PayPal", "Axis Bank"]),
        "brand": rng.choice(["Amazon", "Netflix", "Apple", "Microsoft", "PayPal"]),
        "courier": rng.choice(["FedEx", "DHL", "USPS", "India Post", "UPS"]),
        "amount": rng.choice(["$", "Rs.", "£"]) + f"{rng.randint(100, 9999)}",
        "small": rng.choice(["$", "Rs.", "£"]) + f"{rng.randint(1, 9)}.{rng.randint(10, 99)}",
        "code": f"{rng.randint(100000, 999999)}",
        "phone": f"+1-8{rng.randint(10, 99)}-{rng.randint(100, 999)}-{rng.randint(1000, 9999)}",
        "url": make_phish_url(rng),
        "legit_url": make_legit_url(rng),
        "name": rng.choice(["Sam", "Priya", "Alex", "Mom", "John", "Dr. Rao", "Maria"]),
        "time": rng.choice(["5pm", "tomorrow at 10", "tonight", "Friday", "noon", "8:30 am"]),
        "place": rng.choice(["station", "cafe", "library", "office", "mall"]),
    }


def generate_synthetic_sms(n_per_class: int = 600, seed: int = 42) -> pd.DataFrame:
    rng = random.Random(seed)
    rows: List[tuple] = []
    for _ in range(n_per_class):
        rows.append((rng.choice(_SCAM_TEMPLATES).format(**_slots(rng)), 1))
        rows.append((rng.choice(_HAM_TEMPLATES).format(**_slots(rng)), 0))
    rng.shuffle(rows)
    return pd.DataFrame(rows, columns=["text", "label"])