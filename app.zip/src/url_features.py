"""Lexical and host-based URL feature extraction.

Everything here is computed locally from the URL string itself. There are no network
calls (no DNS, WHOIS or page fetching), so analysing a URL never contacts the site.
"""
from __future__ import annotations

import math
import re
from collections import Counter
from typing import Dict, List, Optional, Tuple
from urllib.parse import urlparse

import pandas as pd

SUSPICIOUS_KEYWORDS = (
    "login", "signin", "verify", "secure", "account", "update", "confirm", "password",
    "banking", "wallet", "billing", "suspend", "unlock", "invoice", "payment", "recover",
    "authenticate", "validate", "helpdesk", "bonus", "free", "gift", "prize", "claim",
)
BRANDS = (
    "paypal", "apple", "microsoft", "google", "amazon", "netflix", "facebook", "instagram",
    "whatsapp", "dhl", "fedex", "usps", "chase", "wellsfargo", "bankofamerica", "hdfc",
    "icici", "sbi", "binance", "coinbase", "dropbox", "linkedin",
)
SHORTENERS = {
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly",
    "rebrand.ly", "cutt.ly", "shorturl.at", "tiny.cc",
}
SUSPICIOUS_TLDS = {
    "xyz", "top", "club", "click", "link", "work", "online", "site", "icu", "cyou", "buzz",
    "gq", "tk", "ml", "cf", "ga", "monster", "rest", "zip", "country", "loan", "review",
}
_SECOND_LEVEL_LABELS = {"co", "com", "org", "net", "gov", "edu", "ac"}

_SCHEME_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9+.\-]*://")
_IP_RE = re.compile(r"^\d{1,3}(?:\.\d{1,3}){3}$")
_URL_IN_TEXT_RE = re.compile(
    r"(?i)\b(?:https?://|www\.)[^\s<>\"']+"
    r"|\b(?:[a-z0-9-]+\.)+(?:com|net|org|io|co|in|info|biz|xyz|top|club|click|link|online|site|ly|me|us|uk)\b(?:/[^\s<>\"']*)?"
)

FEATURE_NAMES: List[str] = [
    "url_length", "host_length", "path_length", "query_length",
    "num_dots", "num_hyphens_host", "num_digits", "digit_ratio", "host_digit_count",
    "num_at", "num_question", "num_equals", "num_ampersand", "num_percent", "path_depth",
    "subdomain_count", "tld_length", "host_entropy",
    "has_ip", "uses_https", "has_port", "has_punycode", "double_slash_in_path",
    "suspicious_tld", "is_shortener",
    "keyword_count", "keyword_in_host", "brand_mismatch", "brand_in_path_mismatch",
]


def normalize_url(url: Optional[str]) -> str:
    """Strip whitespace and add https:// if the user typed a bare domain."""
    url = (url or "").strip()
    if not url:
        return ""
    if not _SCHEME_RE.match(url):
        url = "https://" + url.lstrip("/")
    return url


def _safe_parse(url: str) -> Tuple[str, str, Optional[int], str, str]:
    try:
        p = urlparse(url)
        host = (p.hostname or "").lower().rstrip(".")
        try:
            port = p.port
        except ValueError:
            port = None
        return p.scheme.lower(), host, port, p.path or "", p.query or ""
    except ValueError:
        return "", "", None, "", ""


def registered_domain(host: str) -> str:
    """Approximate the registrable domain (e.g. a.b.example.co.uk -> example.co.uk)."""
    if not host or _IP_RE.match(host):
        return host
    labels = host.split(".")
    if len(labels) <= 2:
        return host
    if len(labels[-1]) == 2 and labels[-2] in _SECOND_LEVEL_LABELS:
        return ".".join(labels[-3:])
    return ".".join(labels[-2:])


def shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    counts = Counter(s)
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


def extract_features(url: str) -> Dict[str, float]:
    """Return a dict {feature_name: value} for one URL."""
    raw = (url or "").strip()
    norm = normalize_url(raw)
    scheme, host, port, path, query = _safe_parse(norm)

    is_ip = bool(_IP_RE.match(host))
    reg = registered_domain(host)
    reg_labels = reg.split(".") if reg else []
    host_labels = host.split(".") if host else []
    tld = host_labels[-1] if (host_labels and not is_ip) else ""
    reg_name = reg_labels[0] if (reg_labels and not is_ip) else ""
    path_query = (path + "?" + query).lower() if query else path.lower()
    host_path = (host + path + ("?" + query if query else "")).lower()
    n_digits = sum(ch.isdigit() for ch in raw)

    brand_mismatch = any((b in host) and (reg_name != b) for b in BRANDS)
    brand_in_path = any((b in path_query) for b in BRANDS) and (reg_name not in BRANDS)

    f = {
        "url_length": len(raw),
        "host_length": len(host),
        "path_length": len(path),
        "query_length": len(query),
        "num_dots": raw.count("."),
        "num_hyphens_host": host.count("-"),
        "num_digits": n_digits,
        "digit_ratio": n_digits / max(len(raw), 1),
        "host_digit_count": sum(ch.isdigit() for ch in host),
        "num_at": raw.count("@"),
        "num_question": raw.count("?"),
        "num_equals": raw.count("="),
        "num_ampersand": raw.count("&"),
        "num_percent": raw.count("%"),
        "path_depth": len([p for p in path.split("/") if p]),
        "subdomain_count": 0 if is_ip else max(0, len(host_labels) - len(reg_labels)),
        "tld_length": len(tld),
        "host_entropy": shannon_entropy(host),
        "has_ip": int(is_ip),
        "uses_https": int(scheme == "https"),
        "has_port": int(port is not None and port not in (80, 443)),
        "has_punycode": int("xn--" in host),
        "double_slash_in_path": int("//" in path),
        "suspicious_tld": int(tld in SUSPICIOUS_TLDS),
        "is_shortener": int(reg in SHORTENERS),
        "keyword_count": sum(host_path.count(k) for k in SUSPICIOUS_KEYWORDS),
        "keyword_in_host": int(any(k in host for k in SUSPICIOUS_KEYWORDS)),
        "brand_mismatch": int(brand_mismatch),
        "brand_in_path_mismatch": int(brand_in_path),
    }
    return {k: float(f[k]) for k in FEATURE_NAMES}


def urls_to_frame(urls) -> pd.DataFrame:
    """Build a feature DataFrame (columns = FEATURE_NAMES) from an iterable of URLs."""
    rows = [extract_features(u) for u in urls]
    return pd.DataFrame(rows, columns=FEATURE_NAMES)


def find_urls(text: str) -> List[str]:
    """Find URL-like strings inside a message (order preserved, duplicates removed)."""
    found: List[str] = []
    for m in _URL_IN_TEXT_RE.finditer(text or ""):
        u = m.group(0).rstrip(".,);:!?'\"")
        if u and u not in found:
            found.append(u)
    return found