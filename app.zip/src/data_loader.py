"""Dataset loading.

Public datasets used (downloaded automatically, cached under data/raw/):
  * SMS Spam Collection (UCI Machine Learning Repository, CC BY 4.0), with a GitHub mirror.
  * Phishing URLs: OpenPhish community feed (phishing) + Tranco top-sites list (legitimate domains).

Resolution order for each dataset:
  1. A file you place manually in data/raw/ (see README).
  2. A cached download from a previous run.
  3. A fresh download.
  4. Synthetic fallback (so the project ALWAYS runs, even offline).
"""
from __future__ import annotations

import csv
import io
import random
import zipfile
from typing import List, Optional, Tuple

import pandas as pd
import requests

from src.config import RANDOM_STATE, RAW_DIR, ensure_dirs
from src.synthetic import generate_synthetic_sms, generate_synthetic_urls

SMS_SOURCES = [
    "https://archive.ics.uci.edu/ml/machine-learning-databases/00228/smsspamcollection.zip",
    "https://raw.githubusercontent.com/justmarkham/pycon-2016-tutorial/master/data/sms.tsv",
]
OPENPHISH_FEED = "https://openphish.com/feed.txt"
TRANCO_ZIP = "https://tranco-list.eu/top-1m.csv.zip"

SMS_CACHE = "sms_spam.tsv"
URL_USER_FILE = "urls.csv"            # optional: put your own dataset here (columns: url,label)
URL_CACHE = "urls_downloaded.csv"

_HEADERS = {"User-Agent": "scam-phishing-detector/1.0 (educational project)"}


def _download(url: str, timeout: int = 20) -> Optional[bytes]:
    try:
        r = requests.get(url, timeout=timeout, headers=_HEADERS)
        if r.status_code == 200 and r.content:
            return r.content
    except Exception:
        pass
    return None


# ----------------------------------------------------------------------------- SMS
def parse_sms_tsv(text: str) -> pd.DataFrame:
    """Parse 'label<TAB>message' lines (ham/spam) into a DataFrame[text, label]."""
    df = pd.read_csv(
        io.StringIO(text), sep="\t", header=None, names=["label", "text"],
        quoting=csv.QUOTE_NONE, on_bad_lines="skip", dtype=str,
    )
    df["label"] = df["label"].str.strip().str.lower().map({"ham": 0, "spam": 1})
    df = df.dropna(subset=["label", "text"])
    df["label"] = df["label"].astype(int)
    return df[["text", "label"]].reset_index(drop=True)


def _fetch_sms_text() -> Optional[str]:
    for src in SMS_SOURCES:
        blob = _download(src)
        if not blob:
            continue
        try:
            if src.endswith(".zip"):
                with zipfile.ZipFile(io.BytesIO(blob)) as zf:
                    name = next(n for n in zf.namelist() if "SMSSpamCollection" in n and not n.endswith("/"))
                    return zf.read(name).decode("utf-8", errors="replace")
            return blob.decode("utf-8", errors="replace")
        except Exception:
            continue
    return None


def load_sms_dataset(offline: bool = False, augment: bool = True) -> Tuple[pd.DataFrame, str]:
    """Return (DataFrame[text, label], human-readable source description). label 1 = scam/spam."""
    ensure_dirs()
    real: Optional[pd.DataFrame] = None
    if not offline:
        cache = RAW_DIR / SMS_CACHE
        text = None
        if cache.exists():
            text = cache.read_text(encoding="utf-8", errors="replace")
        else:
            text = _fetch_sms_text()
            if text:
                cache.write_text(text, encoding="utf-8")
        if text:
            try:
                parsed = parse_sms_tsv(text)
                if len(parsed) >= 1000 and parsed["label"].nunique() == 2:
                    real = parsed
            except Exception:
                real = None

    if real is None:
        df = generate_synthetic_sms(n_per_class=1500, seed=RANDOM_STATE)
        return df, "Synthetic template-based SMS data (offline fallback)"

    if augment:
        extra = generate_synthetic_sms(n_per_class=500, seed=RANDOM_STATE)
        df = pd.concat([real, extra], ignore_index=True)
        return df, "SMS Spam Collection (public, real) + synthetic modern-scam augmentation"
    return real, "SMS Spam Collection (public, real)"


# ----------------------------------------------------------------------------- URLs
def _normalize_labels(series: pd.Series) -> pd.Series:
    mapping = {
        "1": 1, "0": 0, "phishing": 1, "bad": 1, "malicious": 1, "malware": 1, "defacement": 1,
        "legitimate": 0, "good": 0, "benign": 0, "safe": 0,
    }
    return series.astype(str).str.strip().str.lower().map(mapping)


def load_user_url_file() -> Optional[pd.DataFrame]:
    path = RAW_DIR / URL_USER_FILE
    if not path.exists():
        return None
    try:
        df = pd.read_csv(path)
        df.columns = [c.strip().lower() for c in df.columns]
        if "url" not in df.columns or "label" not in df.columns:
            return None
        df["label"] = _normalize_labels(df["label"])
        df = df.dropna(subset=["url", "label"])
        df["label"] = df["label"].astype(int)
        return df[["url", "label"]] if len(df) >= 200 and df["label"].nunique() == 2 else None
    except Exception:
        return None


def build_url_df_from_feeds(phish_urls: List[str], legit_domains: List[str], seed: int = RANDOM_STATE) -> pd.DataFrame:
    """Combine real phishing URLs with real legitimate domains.

    Tranco only lists domains, so we attach typical page paths to each domain. Without
    this, a model could cheat by learning 'has a path => phishing'.
    """
    rng = random.Random(seed)
    words = ["news", "about", "products", "help", "blog", "docs", "search", "login", "contact", "pricing"]
    legit = []
    for d in legit_domains:
        d = d.strip().lower()
        if not d or " " in d:
            continue
        w = rng.choice(words)
        path = rng.choice(["", "/", f"/{w}", f"/{w}/{rng.randint(1, 9999)}", f"/{w}?id={rng.randint(1, 999)}"])
        legit.append(f"https://{'www.' if rng.random() < 0.4 else ''}{d}{path}")
    phish = [u.strip() for u in phish_urls if u.strip().lower().startswith(("http://", "https://"))]
    n = min(len(phish), len(legit))
    df = pd.DataFrame({"url": phish[:n] + legit[:n], "label": [1] * n + [0] * n})
    return df.sample(frac=1.0, random_state=seed).reset_index(drop=True)


def _download_url_feeds() -> Optional[pd.DataFrame]:
    phish_blob = _download(OPENPHISH_FEED)
    tranco_blob = _download(TRANCO_ZIP, timeout=60)
    if not phish_blob or not tranco_blob:
        return None
    try:
        phish = phish_blob.decode("utf-8", errors="replace").splitlines()
        with zipfile.ZipFile(io.BytesIO(tranco_blob)) as zf:
            name = zf.namelist()[0]
            lines = zf.read(name).decode("utf-8", errors="replace").splitlines()
        domains = [ln.split(",", 1)[1] for ln in lines[:20000] if "," in ln]
        random.Random(RANDOM_STATE).shuffle(domains)
        df = build_url_df_from_feeds(phish, domains[:5000])
        return df if len(df) >= 400 else None
    except Exception:
        return None


def load_url_dataset(offline: bool = False, augment: bool = True) -> Tuple[pd.DataFrame, str]:
    """Return (DataFrame[url, label], source description). label 1 = phishing."""
    ensure_dirs()
    if not offline:
        user_df = load_user_url_file()
        if user_df is not None:
            return user_df, f"User-provided dataset (data/raw/{URL_USER_FILE})"

        cache = RAW_DIR / URL_CACHE
        real: Optional[pd.DataFrame] = None
        if cache.exists():
            try:
                real = pd.read_csv(cache)
            except Exception:
                real = None
        if real is None:
            real = _download_url_feeds()
            if real is not None:
                real.to_csv(cache, index=False)
        if real is not None and len(real) >= 400:
            if augment:
                extra = generate_synthetic_urls(n_per_class=500, seed=RANDOM_STATE)
                return (pd.concat([real, extra], ignore_index=True),
                        "OpenPhish feed + Tranco top sites (public, real) + synthetic augmentation")
            return real, "OpenPhish feed + Tranco top sites (public, real)"

    return generate_synthetic_urls(n_per_class=2000, seed=RANDOM_STATE), "Synthetic URL data (offline fallback)"