"""Inference: load trained models, score URLs and messages, build explanations."""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional

import joblib
import numpy as np
import pandas as pd

from src.config import HIGH_THRESHOLD, LOW_THRESHOLD, MESSAGE_MODEL_FILE, MODELS_DIR, URL_MODEL_FILE
from src.explain import FEATURE_LABELS, heuristic_score, message_flags, url_flags
from src.url_features import FEATURE_NAMES, extract_features, find_urls


def models_ready(models_dir: Path = MODELS_DIR) -> bool:
    models_dir = Path(models_dir)
    return (models_dir / MESSAGE_MODEL_FILE).exists() and (models_dir / URL_MODEL_FILE).exists()


def risk_level(score: float) -> str:
    if score < LOW_THRESHOLD:
        return "Low"
    if score < HIGH_THRESHOLD:
        return "Medium"
    return "High"


def _positive_proba(model, X) -> float:
    classes = list(model.classes_)
    return float(model.predict_proba(X)[0, classes.index(1)])


class ScamDetector:
    """Loads both models once and exposes analyze_url() and analyze_message()."""

    def __init__(self, models_dir: Optional[Path] = None):
        models_dir = Path(models_dir) if models_dir else MODELS_DIR
        if not models_ready(models_dir):
            raise FileNotFoundError(
                f"Trained models not found in {models_dir}. Run `python -m src.train` first."
            )
        self.url_bundle = joblib.load(models_dir / URL_MODEL_FILE)
        self.msg_bundle = joblib.load(models_dir / MESSAGE_MODEL_FILE)

    # ------------------------------------------------------------------ URL
    def analyze_url(self, url: str) -> Dict:
        url = (url or "").strip()
        if not url:
            raise ValueError("Please provide a URL.")
        names: List[str] = self.url_bundle["feature_names"]
        feats = extract_features(url)
        X = pd.DataFrame([feats], columns=names)
        ml_prob = _positive_proba(self.url_bundle["model"], X)

        flags = url_flags(feats)
        h_score = heuristic_score(flags)
        risk = round(100.0 * (0.75 * ml_prob + 0.25 * h_score), 1)

        # Model signals: how unusual each feature is, weighted by how much the model relies on it.
        x = X.iloc[0].to_numpy(dtype=float)
        z = (x - self.url_bundle["mean"]) / self.url_bundle["std"]
        impact = self.url_bundle["importances"] * np.abs(z)
        signals = []
        for i in np.argsort(impact)[::-1][:5]:
            if impact[i] <= 0:
                continue
            signals.append({
                "feature": FEATURE_LABELS.get(names[i], names[i]),
                "value": round(float(x[i]), 3),
                "direction": "higher than typical" if z[i] > 0 else "lower than typical",
                "impact": round(float(impact[i]), 4),
            })
        return {
            "type": "url", "input": url, "ml_probability": round(ml_prob, 4),
            "heuristic_score": round(h_score, 3), "risk_score": risk, "risk_level": risk_level(risk),
            "flags": flags, "model_signals": signals, "features": feats,
        }

    # -------------------------------------------------------------- message
    def analyze_message(self, text: str) -> Dict:
        text = (text or "").strip()
        if not text:
            raise ValueError("Please provide a message.")
        pipe = self.msg_bundle["pipeline"]
        ml_prob = _positive_proba(pipe, [text])

        flags = message_flags(text)
        r_score = heuristic_score(flags)

        url_results = [self.analyze_url(u) for u in find_urls(text)]
        if url_results:
            flags.append({"label": f"Contains {len(url_results)} link(s)", "weight": 0.0})
            max_url = max(r["risk_score"] for r in url_results) / 100.0
            combined = 0.55 * ml_prob + 0.15 * r_score + 0.30 * max_url
            if max_url >= 0.7:   # a clearly malicious link should dominate
                combined = max(combined, 0.9 * max_url)
        else:
            combined = 0.8 * ml_prob + 0.2 * r_score
        risk = round(100.0 * float(min(1.0, max(0.0, combined))), 1)

        return {
            "type": "message", "input": text, "ml_probability": round(ml_prob, 4),
            "heuristic_score": round(r_score, 3), "risk_score": risk, "risk_level": risk_level(risk),
            "flags": flags, "word_contributions": self._word_contributions(text),
            "url_results": url_results,
        }

    def _word_contributions(self, text: str, top_n: int = 8) -> Dict[str, List[Dict]]:
        """Exact linear contributions (coefficient x tf-idf value) of each word/phrase."""
        pipe = self.msg_bundle["pipeline"]
        tfidf, clf = pipe.named_steps["tfidf"], pipe.named_steps["clf"]
        coef = clf.coef_[0]
        names = tfidf.get_feature_names_out()
        row = tfidf.transform([text]).tocoo()
        items = [(names[j], float(coef[j] * v)) for j, v in zip(row.col, row.data)]
        scam = sorted([i for i in items if i[1] > 0], key=lambda t: -t[1])[:top_n]
        safe = sorted([i for i in items if i[1] < 0], key=lambda t: t[1])[:top_n]
        fmt = lambda lst: [{"term": t, "contribution": round(c, 4)} for t, c in lst]
        return {"scam": fmt(scam), "safe": fmt(safe)}