"""Central configuration: paths, constants, risk thresholds."""
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT_DIR / "data"
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"
MODELS_DIR = ROOT_DIR / "models"
REPORTS_DIR = ROOT_DIR / "reports"

RANDOM_STATE = 42

# Risk score is 0-100. Below LOW = Low risk, below HIGH = Medium, otherwise High.
LOW_THRESHOLD = 30
HIGH_THRESHOLD = 60

MESSAGE_MODEL_FILE = "message_model.joblib"
URL_MODEL_FILE = "url_model.joblib"
METRICS_FILE = "metrics.json"


def ensure_dirs() -> None:
    for d in (RAW_DIR, PROCESSED_DIR, MODELS_DIR, REPORTS_DIR):
        d.mkdir(parents=True, exist_ok=True)