"""Command-line scanner.

    python -m src.cli --url "paypal-secure-login.xyz/verify"
    python -m src.cli --message "Your account is suspended. Verify now: http://bank-verify.top"
"""
import argparse

from src.predictor import ScamDetector, models_ready

def main() -> None:
    parser = argparse.ArgumentParser(description="Scan a URL or message for scam / phishing signals.")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--url", help="URL to analyse (it is never opened)")
    group.add_argument("--message", help="Message text to analyse")
    args = parser.parse_args()

    if not models_ready():
        from src.train import train_all
        print("Models not found - training them first...")
        train_all()

    detector = ScamDetector()
    result = detector.analyze_url(args.url) if args.url else detector.analyze_message(args.message)
    print(f"\nRisk: {result['risk_level']} ({result['risk_score']}/100)  |  ML probability: {result['ml_probability']:.2f}")
    print("Reasons:")
    for f in result["flags"] or [{"label": "No suspicious patterns found"}]:
        print(f"  - {f['label']}")


if __name__ == "__main__":
    main()